// lib/smart_media_player/audio/audio_controller.dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';

class AudioController {
  final AudioPlayer player;
  final double _volume = 1.0;
  final double _speed = 1.0;

  AudioController(this.player);

  Future<void> pickAndLoadFile({
    required BuildContext context,
    required void Function(String) onFileLoaded,
  }) async {
    String? filePath;

    if (Platform.isMacOS) {
      filePath = await _openMacOSFilePicker();
    } else {
      // TODO: 다른 플랫폼 처리 필요 시 추가
    }

    if (filePath != null) {
      debugPrint('🎧 선택된 파일 경로: $filePath');

      await player.setAudioSource(
        AudioSource.uri(Uri.file(filePath), tag: filePath),
      );
      await player.setVolume(_volume);
      await player.setSpeed(_speed);

      onFileLoaded(filePath);
    }
  }

  Future<String?> _openMacOSFilePicker() async {
    final script = '''
    set selectedFile to choose file of type {"public.audio"} with prompt "음원 파일을 선택하세요"
    set filePath to POSIX path of selectedFile
    return filePath
  ''';

    try {
      final result = await Process.run('osascript', ['-e', script]);

      if (result.exitCode == 0) {
        final output = result.stdout.toString().trim();
        return output.isNotEmpty ? output : null;
      } else {
        debugPrint('❌ stderr: ${result.stderr}');
        return null;
      }
    } catch (e) {
      debugPrint('❌ osascript 실행 오류: $e');
      return null;
    }
  }
}
