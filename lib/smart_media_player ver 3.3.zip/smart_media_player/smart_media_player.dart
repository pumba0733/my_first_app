import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:just_audio/just_audio.dart';

import 'waveform/waveform_view.dart';
import 'audio/bpm_tap_controller.dart';
import 'service/youtube_loader.dart';
import 'service/keyboard_handler.dart';
import 'service/time_formatter.dart';
import 'audio/pitch_controller.dart';
import 'ui/pitch_slider.dart';
import 'ui/tempo_slider.dart';
import 'ui/volume_slider.dart';

class SmartMediaPlayerScreen extends StatefulWidget {
  const SmartMediaPlayerScreen({super.key});

  @override
  State<SmartMediaPlayerScreen> createState() => _SmartMediaPlayerScreenState();
}

class _SmartMediaPlayerScreenState extends State<SmartMediaPlayerScreen> {
  final AudioPlayer _player = AudioPlayer();
  final YouTubeLoader _ytLoader = YouTubeLoader();
  final TextEditingController _ytController = TextEditingController();
  final BpmTapController _bpmController = BpmTapController();
  final PitchController _pitchController = PitchController();

  double _tempo = 1.0;
  double _volume = 1.0;

  final List<double> _waveformData = [];
  final List<Map<String, dynamic>> _comments = [];
  Duration? _loopStart;
  Duration? _loopEnd;

  late KeyboardHandler _keyboardHandler;

  @override
  void initState() {
    super.initState();
    _keyboardHandler = KeyboardHandler(
      player: _player,
      onTogglePlay: _togglePlay,
      onSeekRelative: _seekRelative,
      onSpeedChange: _adjustSpeedBy,
    );
    HardwareKeyboard.instance.addHandler(_keyboardHandler.handleKeyEvent);
  }

  @override
  void dispose() {
    HardwareKeyboard.instance.removeHandler(_keyboardHandler.handleKeyEvent);
    _player.dispose();
    super.dispose();
  }

  void _togglePlay() async {
    if (_player.playing) {
      await _player.pause();
    } else {
      await _player.play();
    }
    setState(() {});
  }

  void _seekRelative(Duration offset) {
    final newPos = _player.position + offset;
    _player.seek(newPos);
  }

  void _adjustSpeedBy(double delta) {
    setState(() {
      _tempo = (_tempo + delta).clamp(0.1, 2.0);
      _player.setSpeed(_tempo);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("SmartMediaPlayer v3.3")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: StreamBuilder<Duration>(
          stream: _player.positionStream,
          builder: (context, snapshot) {
            final position = snapshot.data ?? Duration.zero;
            final duration = _player.duration ?? const Duration(seconds: 1);
            final positionText = formatDuration(position);
            final durationText = formatDuration(duration);

            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  controller: _ytController,
                  decoration: const InputDecoration(labelText: 'YouTube URL'),
                  onSubmitted: (value) {
                    _ytLoader.loadFromUrl(value, context);
                  },
                ),
                const SizedBox(height: 12),
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey.shade400),
                  ),
                  height: 120,
                  child: WaveformView(
                    waveform: _waveformData,
                    bpmMarks: _bpmController.bpmMarks,
                    currentPosition: position,
                    totalDuration: duration,
                    playheadPosition: position,
                    loopStart: _loopStart,
                    loopEnd: _loopEnd,
                    bpmController: _bpmController,
                    comments: _comments,
                    onSeek: (pos) => _player.seek(pos),
                    onSetLoopStart: (pos) => setState(() => _loopStart = pos),
                    onSetLoopEnd: (pos) => setState(() => _loopEnd = pos),
                    onUpdateCommentPosition: (label, newPos) {
                      setState(() {
                        final index =
                            _comments.indexWhere((c) => c['label'] == label);
                        if (index != -1) {
                          _comments[index]['position'] = newPos;
                        }
                      });
                    },
                  ),
                ),
                const SizedBox(height: 8),
                Center(
                  child: Text(
                    '$positionText / $durationText',
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: TempoSlider(
                        tempo: _tempo,
                        onChanged: (value) {
                          setState(() {
                            _tempo = value;
                            _player.setSpeed(_tempo);
                          });
                        },
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: VolumeSlider(
                        volume: _volume,
                        onChanged: (value) {
                          setState(() {
                            _volume = value;
                            _player.setVolume(_volume);
                          });
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: PitchSlider(
                        pitchSemitone: _pitchController.pitchSemitone,
                        onChanged: (value) {
                          setState(() {
                            _pitchController.setPitchSemitone(value);
                          });
                        },
                      ),
                    ),
                    const SizedBox(width: 16),
                    Wrap(
                      spacing: 6,
                      children: [50, 60, 70, 80, 90, 100].map((percent) {
                        return ElevatedButton(
                          onPressed: () {
                            final newTempo = percent / 100.0;
                            setState(() {
                              _tempo = newTempo;
                              _player.setSpeed(_tempo);
                            });
                          },
                          child: Text('$percent%'),
                        );
                      }).toList(),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    GestureDetector(
                      onTapDown: (_) => _player.setSpeed(1.5),
                      onTapUp: (_) => _player.setSpeed(_tempo),
                      child: const Icon(Icons.fast_rewind, size: 32),
                    ),
                    const SizedBox(width: 24),
                    GestureDetector(
                      onTapDown: (_) => _player.setSpeed(1.5),
                      onTapUp: (_) => _player.setSpeed(_tempo),
                      child: const Icon(Icons.fast_forward, size: 32),
                    ),
                  ],
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
